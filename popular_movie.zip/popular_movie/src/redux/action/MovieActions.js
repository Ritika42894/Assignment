export const addMovieData = (data) => {
  console.debug(data);
  return {type:"INSERT", data}
}
