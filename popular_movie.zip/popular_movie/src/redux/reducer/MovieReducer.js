const defaultState  = [];

const MovieReducer = (state = defaultState,action) => {
  switch (action.type) {
    case "INSERT":
      let t = Array.from(state);
      t.push(...action.data);
      console.debug(action,state,t);
      return t;
    default: return state;
  }
}

export default MovieReducer;
