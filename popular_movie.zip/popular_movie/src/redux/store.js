import {configureStore} from '@reduxjs/toolkit';
import MovieReducer from "./reducer/MovieReducer";

export default configureStore({
  reducer: {
    MovieReducer
  }
})
