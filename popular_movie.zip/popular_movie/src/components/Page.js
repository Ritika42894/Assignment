import React from 'react';
import {makeStyles} from "@material-ui/core";

const useStyles = makeStyles(theme => ({
  root: {
    width: '100vw',
    maxWidth: "100vw",
    height: '100%',
    color: '#e7beff',
    overflowX: "hidden",
    paddingTop: 70
  }
}));

const Page = (props) => {
  const  classes = useStyles();
  return (
    <div className={classes.root}>
      {props.children}
    </div>
  );
};

export default Page;
