import React from 'react';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import Movie from "../model/Movie";
import {Chip, Container} from "@material-ui/core";
import Page from "./Page";
import CustomLink from "./CustomLink";

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    "&:hover":{
      boxShadow: "2px 3px 4px #92727f"
    },
    height: "100%",
  },
  details: {
    display: 'flex',
    flexDirection: 'column',
  },
  content: {
    flex: '1 0 auto',
  },
  cover: {
    width: 300,
  },
  controls: {
    display: 'flex',
    alignItems: 'center',
    paddingLeft: theme.spacing(1),
    paddingBottom: theme.spacing(1),
  },
  playIcon: {
    height: 38,
    width: 38,
  },
}));

export default function MovieCard(props) {
  const classes = useStyles();
  const theme = useTheme();

  const m = new Movie(props.data);

  return (
    <Card className={classes.root}>
      <CardMedia
        className={classes.cover}
        image={`${m.posterPath}`}
        title={m.title}
      />
      <div className={classes.details}>
        <CardContent className={classes.content}>
          <Typography component="h5" variant="h5">
            {m.title}
          </Typography>
          <Typography variant="subtitle1" color="textSecondary">
            {`⚫${m.release_date}  ⚫ Popularity: ${m.popularity}  ⚫ Rating: ${m.vote_average}`}
          </Typography>
          <div>
            {m.genres.map(genre => <Chip size="small" label={genre.name} key={genre.id}/>)}
          </div>
          <Typography variant="body1" color="textSecondary">
            {m.overview.slice(0,200)} <CustomLink href={m.homepage}><span style={{color: "#312AFB"}}>See More</span></CustomLink>
          </Typography>
        </CardContent>
      </div>
    </Card>
  );
}
