const constants = {
  api_key: "4e44d9029b1270a757cddc766a1bcb63",
  imageURL: "https://image.tmdb.org/t/p/w300"
}

export default constants;
