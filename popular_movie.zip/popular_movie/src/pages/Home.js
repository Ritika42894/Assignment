import React, {useEffect, useState} from 'react';
import MovieCard from "../components/MovieCard";
import Typography from "@material-ui/core/Typography";
import Grid from "@material-ui/core/Grid";
import {useDispatch, useSelector} from "react-redux";
import Page from "../components/Page";
import {Container} from "@material-ui/core";
import {useLocation} from "react-router-dom";
import axios from "axios";
import constants from "../constants";
import {addMovieData} from "../redux/action/MovieActions";

const Home = () => {

  const movieList = useSelector((state) => state.MovieReducer);
  const location = useLocation();
  const usp = new URLSearchParams(location.search);
  const [pageNumber,setPageNumber] = useState(usp.get("page") || 1);
  const dispatch = useDispatch();

  useEffect(() => {
    const usp = new URLSearchParams(location.search);
    setPageNumber(usp.get("page") || 1);
  },[location.search])


  useEffect(() => {

    axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=${constants.api_key}&page=${pageNumber}`).then(res => {
      // console.debug(res.data.results);
      dispatch(addMovieData(res.data.results));
    }).catch(e => {
      console.error(e);
    })

  }, [pageNumber]);


  return (
    <Page>
      <Grid container direction="column" spacing={2}>
        <Grid item xs={12} sm={10} md={5} lg={5} xl={5}>
          <Typography variant='h1' align="center">
            Popular Movies
          </Typography>
        </Grid>
        <Grid item>
          <Grid container spacing={2} justify="center" alignItems="stretch">
            {
              movieList.map((movie) =>
                <Grid item xs={12} sm={10} md={5} lg={5} xl={5}>
                  <MovieCard data={movie} />
                </Grid>)
            }
          </Grid>
        </Grid>
      </Grid>
    </Page>
  );
};

export default Home;
