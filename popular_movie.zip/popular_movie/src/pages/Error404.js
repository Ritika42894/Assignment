import React from 'react';
import Page from "../components/Page";
import Grid from "@material-ui/core/Grid";
import {Typography} from "@material-ui/core";

const Error404 = () => {
  return (
    <Page>
      <Grid container alignItems="center" justify="center" style={{height:"100%"}} >
        <Grid item>
          <img src="/logo192.png" width="100px" height="100px" alt="React Error404" id="reactiveLogo"/>
        </Grid>
        <Grid item>
          <Typography variant="h5" color="error">
            404:  Page Not Found
          </Typography>
        </Grid>
      </Grid>
    </Page>
  );
};

export default Error404;
