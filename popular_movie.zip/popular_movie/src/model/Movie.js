import constants from "../constants";

class Movie{
  constructor({title,tagline,vote_average,vote_count,revenue,release_date,popularity,overview,original_title,genres,homepage,poster_path,backdrop_path,id}) {
    this.title = title;
    this.tagline = tagline;
    this.vote_average = vote_average;
    this.vote_count = vote_count;
    this.revenue = revenue;
    this.release_date = release_date;
    this.popularity = popularity;
    this.original_title = original_title;
    this.overview = overview;
    this.genres = genres || [];
    this.homepage = homepage;
    this.poster_path = poster_path;
    this.backdrop_path = backdrop_path;
    this.id = id;
    this.api_path = `https://api.themoviedb.org/3/movie/${id}`
  }

  get posterPath() {
    return `${constants.imageURL}${this.poster_path}`
  }
  get backdropPath() {
    return `${constants.imageURL}${this.backdrop_path}`
  }
}

export default Movie;
