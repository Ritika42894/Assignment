# External Packages:

1. @mantine/core
1. @mantine/notifications
1. @mantine/hooks
1. react-jss
1. redux-saga
1. @reduxjs/toolkit
1. axios

